package bild_in_console.app;

import bild_in_console.app.bild_klasse.Bilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@SpringBootApplication
public class DemoApplication {


	public static void main(String[] args) throws IOException {

		SpringApplication.run(DemoApplication.class, args);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Drücken Sie eine Beliebige Taste.....");
		br.readLine();
	}

	@Autowired
	@Bean
	public CommandLineRunner bildzeichneninconsole (Bilder bild)
	{
		return (args) ->
		{
			System.out.println(bild.getBildergezeichnet());


		};

	}

}
