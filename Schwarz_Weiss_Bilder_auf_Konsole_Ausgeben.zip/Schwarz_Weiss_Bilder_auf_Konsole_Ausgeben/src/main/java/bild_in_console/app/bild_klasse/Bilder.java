package bild_in_console.app.bild_klasse;

import bild_in_console.app.DemoApplication;
import bild_in_console.app.exeptions.Ordnerhatkeinbild;
import jline.TerminalFactory;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.activation.MimetypesFileTypeMap;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Component
@Getter
public class Bilder {

    private final String ordnerpfad;

    private static List<File> bilderliste = new ArrayList<>();
    private String ersetzungzeichen;

    private String bildergezeichnet;





    public Bilder(@Value("${bild.ordnername}") String bildordnername, @Value("${bild.ersetzungszeichen}") String ersetzungzeichen) throws IOException {
        ordnerpfad = String.valueOf(Files.createDirectories(Paths.get(System.getProperty("user.dir") + "\\" + bildordnername)));

        File ordner = new File(ordnerpfad);
        File[] dateiliste = ordner.listFiles();
        assert dateiliste != null;

        for (File datei : dateiliste) {

            if (datei.isFile()) {
                String mimetype = new MimetypesFileTypeMap().getContentType(datei);
                String type = mimetype.split("/")[0];
                if (type.equals("image"))
                    bilderliste.add(datei);
            }
        }

        if (bilderliste.size() < 1)
        {
            throw new Ordnerhatkeinbild("Der Ordner " + bildordnername + " unter dem Pfad " + ordnerpfad + " hat kein Bild!");
        }

        this.ersetzungzeichen = ersetzungzeichen;

        bildergezeichnet = bildergezeichnet();







    }

    public String bildergezeichnet()  throws IOException {
        int terminalWidth = TerminalFactory.get().getWidth();
        String ausgabentrennung = ausgabentrennung(terminalWidth);
        String ausgabe = "";

        for (File bild: bilderliste)
        {
            BufferedImage image = ImageIO.read(bild);
            if (image.getWidth() > terminalWidth)
            {
                ausgabe = ausgabe + ausgabentrennung + "\n";
                ausgabe = ausgabe +  "Das angebene Bild: "+ bild.getName() + " unter dem Pfad: " + bild.getPath() + " ist zu groß für die Konsole!\n";
                ausgabe = ausgabe + ausgabentrennung + "\n";
            }
            else
            {
                ausgabe = ausgabe + "Bild: " + bild.getName() + "\n";
                ausgabe = ausgabe + ausgabentrennung + "\n";
                Color[][] colors = new Color[image.getWidth()][image.getHeight()];
                for (int y = 0 ; y < image.getHeight(); y++)
                {
                    for (int x=0; x < image.getWidth(); x++)
                    {
                        colors[x][y] = new Color(image.getRGB(x, y));
                        if (colors[x][y].equals(Color.black))
                        {
                            ausgabe = ausgabe + ersetzungzeichen;
                        }
                        else
                        {
                            ausgabe = ausgabe + " ";
                        }
                    }

                    ausgabe = ausgabe + "\n";

                }

            }

        }
        return ausgabe;
    }

    public static String ausgabentrennung(int consolenbreite)
    {
        String ausgabe  = "";
        for (int i = 1; i <= consolenbreite; i++)
        {
            ausgabe = ausgabe + "-";
        }
        return ausgabe;
    }
}
