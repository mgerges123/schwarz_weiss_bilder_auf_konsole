package bild_in_console.app.exeptions;

public class Ordnerhatkeinbild extends RuntimeException{

    public Ordnerhatkeinbild(String message) {
        super(message);
    }

}
